/*
** xerror.c for raytracer in /u/epitech_2012/ampe_e/cu/public/raytracer
** 
** Made by emilien ampe
** Login   <ampe_e@epitech.net>
** 
** Started on  Fri May 23 06:06:57 2008 emilien ampe
** Last update Fri May 23 06:07:38 2008 emilien ampe
*/

#include "raytracer.h"

void	xerror(char *str)
{
  my_putstr(str);
  exit(0);
}
